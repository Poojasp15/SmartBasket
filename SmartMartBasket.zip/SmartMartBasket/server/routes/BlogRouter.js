import express from "express"
import { createBook, deleteBookById, getAllBooks, updateBookById, getByTechnology } from "../controller/BlogController.js";

const blogRouter = express.Router();

blogRouter.post("/create", createBook);
blogRouter.get("/", getAllBooks);
blogRouter.get("/getByTechnology/:technology", getByTechnology);
blogRouter.put("/updateById/:id", updateBookById);
blogRouter.delete("/deleteById/:id", deleteBookById);

export default blogRouter;
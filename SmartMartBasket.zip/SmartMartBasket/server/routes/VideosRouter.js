import express from "express"
import { createBook, deleteBookById, getAllBooks, getByTechnology, updateBookById } from "../controller/VideoController.js";

const videoRouter = express.Router();

videoRouter.post("/create", createBook);
videoRouter.get("/", getAllBooks);
videoRouter.get("/getByTechnology/:technology", getByTechnology);
videoRouter.put("/updateById/:id", updateBookById);
videoRouter.delete("/deleteById/:id", deleteBookById);

export default videoRouter;
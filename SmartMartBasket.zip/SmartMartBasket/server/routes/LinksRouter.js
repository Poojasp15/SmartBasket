import express from "express"
import { createBook, deleteBookById, getAllBooks, getByTechnology, updateBookById } from "../controller/LinksController.js";

const linksRouter = express.Router();

linksRouter.post("/create", createBook);
linksRouter.get("/", getAllBooks);
linksRouter.get("/getByTechnology/:technology", getByTechnology);
linksRouter.put("/updateById/:id", updateBookById);
linksRouter.delete("/deleteById/:id", deleteBookById);

export default linksRouter;
import express from "express";
import multer from "multer";

import {
    createBook,
    deleteBookById,
    getAllBooks,
    getByTechnology,
    updateBookById
} from "../controller/BookController.js";

const bookRouter = express.Router();

bookRouter.post("/createBook", createBook); // Add file upload middleware
bookRouter.get("/", getAllBooks);
bookRouter.get("/getByTechnology/:technology", getByTechnology);
bookRouter.put("/updateBookById/:id", updateBookById); // Add file upload middleware
bookRouter.delete("/deleteBookById/:id", deleteBookById);

export default bookRouter;

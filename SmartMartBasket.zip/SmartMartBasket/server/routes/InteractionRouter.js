import express from "express"
import { createNotification, deleteNotificationById, getAllNotifications, getNotificationsByColege, updateNotificationById } from "../controller/InteractionController.js";

const interactionRouter = express.Router();

interactionRouter.post("/postInteraction", createNotification);
interactionRouter.get("/", getAllNotifications);
interactionRouter.get("/findByCollege/:college_id", getNotificationsByColege)
interactionRouter.put("/updateNotificationById/:id", updateNotificationById);
interactionRouter.delete("/deleteNotificationById/:id", deleteNotificationById);

export default interactionRouter;
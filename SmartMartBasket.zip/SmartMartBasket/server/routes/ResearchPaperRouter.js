import express from "express"
import { createBook, deleteBookById, getAllBooks, getByTechnology, updateBookById } from "../controller/ResearchPaperController.js";

const researchParperRouter = express.Router();

researchParperRouter.post("/create", createBook);
researchParperRouter.get("/", getAllBooks);
researchParperRouter.get("/getByTechnology/:technology", getByTechnology);
researchParperRouter.put("/updateById/:id", updateBookById);
researchParperRouter.delete("/deleteById/:id", deleteBookById);

export default researchParperRouter;
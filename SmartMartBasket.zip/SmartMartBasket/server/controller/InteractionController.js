import Interaction from '../models/Interaction.js'; // Adjust the import path according to your project structure

export const createNotification = async (req, res) => {
    try {
        const { user_id, answer_id, liked, unliked, comment } = req.body;

        // Find existing interaction
        let existingInteraction = await Interaction.findOne({ user_id, answer_id });

        if (existingInteraction) {
            // Update existing interaction
            if (liked) {
                existingInteraction.liked = true;
                existingInteraction.unliked = false;
            } else if (unliked) {
                existingInteraction.liked = false;
                existingInteraction.unliked = true;
            }

            // Update comment if provided
            if (comment) {
                // Add new comment to the array if it is not already present
                if (!existingInteraction.comments.includes(comment)) {
                    existingInteraction.comments.push(comment);
                }
            }

            await existingInteraction.save();
        } else {
            // Create a new interaction
            const newInteraction = new Interaction({ user_id, answer_id, liked, unliked, comments: comment ? [comment] : [] });
            await newInteraction.save();
        }

        return res.status(200).json({ message: 'Interaction processed successfully' });

    } catch (err) {
        console.error('Error processing interaction:', err);
        return res.status(500).json({ message: 'An error occurred while processing your request' });
    }
};


export const getAllNotifications = async (req, res) => {
    try {
        return res.status(200).json(await Interaction.find());
    } catch (err) {
        console.error('Error fetching categories:', err);
        return res.status(500).json({ message: 'An error occurred while processing your request' });
    }
};

export const getNotificationsByColege = async (req, res) => {
    try {
        return res.status(200).json(await Interaction.find({ college_id: req.params.college_id }));
    } catch (err) {
        console.error('Error fetching categories:', err);
        return res.status(500).json({ message: 'An error occurred while processing your request' });
    }
};



export const updateNotificationById = async (req, res) => {

    const { id } = req.params;
    const updateData = req.body;

    try {
        const interraction = await Interraction.findByIdAndUpdate(id, updateData, { new: true });

        return res.status(200).json({ data: interraction });

    } catch (error) {
        console.error(error);
        return res.status(500)
            .json({ message: 'Internal server error', error });
    }
}


export const deleteNotificationById = async (req, res) => {
    const { id } = req.params;

    try {
        const interraction = await Interraction.findByIdAndDelete(id, { new: true });

        return res.status(200).json({ data: interraction });

    } catch (error) {
        console.error(error);
        return res.status(500)
            .json({ message: 'Internal server error', error });
    }
}
import Book from "../models/Links.js";

export const createBook = async (req, res) => {
    try {
        const book = new Book(req.body);

        await book.save();
        return res.status(200).json({ message: 'Book created successfully' });

    } catch (err) {
        console.error('Error creating book:', err);
        return res.status(500).json({ message: 'An error occurred while processing your request' });
    }
};

export const getAllBooks = async (req, res) => {
    try {
        return res.status(200).json(await Book.find());
    } catch (err) {
        console.error('Error fetching categories:', err);
        return res.status(500).json({ message: 'An error occurred while processing your request' });
    }
};

export const getByTechnology = async (req, res) => {
    try {
        return res.status(200).json(await Book.find({ technology: req.params.technology }));
    } catch (err) {
        console.error('Error fetching categories:', err);
        return res.status(500).json({ message: 'An error occurred while processing your request' });
    }
}

export const updateBookById = async (req, res) => {

    const { id } = req.params;
    const updateData = req.body;

    try {
        const book = await Book.findByIdAndUpdate(id, updateData, { new: true });

        return res.status(200).json({ data: book });

    } catch (error) {
        console.error(error);
        return res.status(500)
            .json({ message: 'Internal server error', error });
    }
}

export const deleteBookById = async (req, res) => {
    const { id } = req.params;

    try {
        const book = await Book.findByIdAndDelete(id, { new: true });

        return res.status(200).json({ data: book });

    } catch (error) {
        console.error(error);
        return res.status(500)
            .json({ message: 'Internal server error', error });
    }
}
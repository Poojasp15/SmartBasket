import express from "express";
import cors from "cors";
import mongoose from "mongoose";
import dotenv from "dotenv";
import bodyParser from "body-parser";
import cookieParser from "cookie-parser";
import multer from "multer";
import path from "path";
import fs from "fs";

// Import routers
import userRouter from "./routes/UserRouter.js";
import categoryRouter from "./routes/CategoryRouter.js";
import notificationRouter from "./routes/NotificationsRouter.js";
import techExpertRouter from "./routes/TechExpertRouter.js";
import adminRouter from "./routes/AdminRouter.js";
import technologyRouter from "./routes/TechnologyRouter.js";
import errorTypeRoute from "./routes/ErrorTypeRouter.js";
import answerRouter from "./routes/AnswersRoute.js";
import bookRouter from "./routes/BookRouter.js";
import linksRouter from "./routes/LinksRouter.js";
import researchPaperRouter from "./routes/ResearchPaperRouter.js";
import blogRouter from "./routes/BlogRouter.js";
import videoRouter from "./routes/VideosRouter.js";
import interactionRouter from "./routes/InteractionRouter.js";
import subcategoryRouter from "./routes/SubcategoryRouter.js";
import itemsRouter from "./routes/ItemsRouter.js";

dotenv.config();

const corsOptions = {
    origin: 'http://localhost:3000', // Allow only this origin
    credentials: true, // Allow credentials (cookies)
    optionsSuccessStatus: 200 // For legacy browser support
};

const app = express();
app.use(bodyParser.json());
app.use(cors(corsOptions));
app.use(cookieParser());

// Mount routers
app.use("/user", userRouter);
app.use("/category", categoryRouter);
app.use("/subcategory", subcategoryRouter)
app.use("/notification", notificationRouter);
app.use("/techExpert", techExpertRouter);
app.use("/admin", adminRouter);
app.use("/technology", technologyRouter);
app.use("/errorType", errorTypeRoute);
app.use("/answers", answerRouter);
app.use("/book", bookRouter);
app.use("/link", linksRouter);
app.use("/researchPaper", researchPaperRouter);
app.use("/blog", blogRouter);
app.use("/video", videoRouter);
app.use("/interaction", interactionRouter);
app.use("/item", itemsRouter);

// MongoDB connection
const PORT = process.env.PORT || 7000;
const URL = process.env.MONGOURL;

mongoose.connect(URL, { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => {
        console.log("DB Connected Successfully");
        app.listen(PORT, () => {
            console.log(`Server is running on Port: ${PORT}`);
        });
    })
    .catch(error => console.log(error));

// Set up upload directory
const uploadDirectory = path.join(path.resolve(), 'uploads');

// Ensure the uploads directory exists
if (!fs.existsSync(uploadDirectory)) {
    fs.mkdirSync(uploadDirectory, { recursive: true }); // Use recursive to create nested directories if needed
}

// Multer configuration for file uploads
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, uploadDirectory); // Set destination to your uploadDirectory
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + '-' + file.originalname); // Unique filename
    }
});

const upload = multer({ storage });

// File upload endpoint
app.post('/api/upload', upload.single('file'), (req, res) => {
    if (!req.file) {
        return res.status(400).json({ message: 'No file uploaded.' });
    }

    // Return the file path (you can adjust this as needed)
    const filePath = path.join('uploads', req.file.filename);
    res.status(200).json({ filePath });
});

// Middleware to serve static files
app.use('/uploads', express.static(uploadDirectory));

// File download endpoint
app.get('/api/download/uploads/:filename', (req, res) => {
    const fileName = req.params.filename; // This extracts the filename correctly
    const filePath = path.join(uploadDirectory, fileName); // This builds the correct file path

    res.download(filePath, (err) => {
        if (err) {
            console.error("File download error:", err);
            res.status(404).send('File not found');
        }
    });
});

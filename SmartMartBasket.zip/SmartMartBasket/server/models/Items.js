import mongoose, { Schema } from "mongoose";

const ItemSchema = new Schema({
    category: {
        type: Schema.Types.ObjectId,
        ref: 'Category', // Assuming there's a Category model
        required: true
    },
    subCategory: {
        type: Schema.Types.ObjectId,
        ref: 'Subcategory', // Assuming there's a Subcategory model
        required: true
    },
    itemName: {
        type: String,
        required: true,
        trim: true // Trims whitespace
    },
    itemPrice: {
        type: Number,
        required: true,
        min: 0 // Ensures price is non-negative
    }
}, {
    timestamps: true // Automatically manages createdAt and updatedAt fields
});

export default mongoose.model("Item", ItemSchema);

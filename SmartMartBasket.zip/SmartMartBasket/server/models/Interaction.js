import mongoose, { Schema } from "mongoose";

const InteractionSchema = new Schema({
    user_id: {
        type: Schema.Types.ObjectId,
        ref: 'User',
    },
    answer_id: {
        type: Schema.Types.ObjectId,
        ref: 'College',
    },
    liked: {
        type: Boolean
    },
    unliked: {
        type: Boolean
    },
    comments: [
        {
            type: String
        }
    ], // Array of strings for comments


});


export default mongoose.model("interactions", InteractionSchema);
import mongoose from 'mongoose';

const researchParperSchema = new mongoose.Schema({
    technology: {
        type: mongoose.Types.ObjectId,
        ref: "Technology",
        required: true
    },
    description: {
        type: String,
        trim: true
    },
    link: {
        type: String,
    },
    filePath: {
        type: String
    }
});

export default mongoose.model('ResearchPaper', researchParperSchema);

import React from 'react'
import LeftNavBar from './LeftNavBar'

const AdminLayout = () => {
    return (
        <div>
            <div>
                <LeftNavBar />
            </div>
        </div>
    )
}

export default AdminLayout

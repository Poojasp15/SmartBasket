import React, { useState, useEffect } from 'react';
import { Alert, Button, Col, Container, Form, Row, Table } from 'react-bootstrap';
import { MdDelete, MdEdit } from 'react-icons/md';
import { createBillItem, deleteBillItemById, getAllItems, updateBillItemById } from '../../utils/api';

const Bill = () => {
    const [items, setItems] = useState([]);
    const [billItems, setBillItems] = useState([]);
    const [totalAmount, setTotalAmount] = useState(0);
    const [itemData, setItemData] = useState({ itemId: '', quantity: 1 });
    const [showSuccessAlert, setShowSuccessAlert] = useState(false);
    const [itemErrors, setItemErrors] = useState({});
    const [editItemId, setEditItemId] = useState(null);

    useEffect(() => {
        fetchItems();
    }, []);

    const fetchItems = async () => {
        const response = await getAllItems();
        setItems(await response.json());
    };

    const handleChange = (e) => {
        const { name, value } = e.target;
        setItemData({ ...itemData, [name]: value });
    };

    const validateItemData = () => {
        const errors = {};
        if (!itemData.itemId) errors.itemId = 'Item is required';
        if (itemData.quantity <= 0) errors.quantity = 'Quantity must be greater than 0';
        return errors;
    };

    const handleAddOrEditItem = async () => {
        const errors = validateItemData();
        if (Object.keys(errors).length > 0) {
            setItemErrors(errors);
            return;
        }

        const item = items.find(i => i._id === itemData.itemId);
        if (item) {
            const quantity = parseInt(itemData.quantity, 10);
            const newItem = {
                name: item.itemName,
                price: item.itemPrice,
                quantity,
                total: item.itemPrice * quantity,
            };

            let updatedBillItems;
            try {
                if (editItemId) {
                    // Update existing item
                    await updateBillItemById(editItemId, newItem);
                    updatedBillItems = billItems.map(billItem =>
                        billItem._id === editItemId ? { ...newItem, _id: editItemId } : billItem
                    );
                    setEditItemId(null);
                } else {
                    // Create new item
                    const createdItem = await createBillItem(newItem);
                    // Ensure createdItem contains the necessary properties
                    updatedBillItems = [...billItems, { ...newItem, _id: createdItem._id }];
                }

                setBillItems(updatedBillItems);
                calculateTotal(updatedBillItems);
                setItemData({ itemId: '', quantity: 1 });
                setItemErrors({});
                setShowSuccessAlert(true);
            } catch (error) {
                console.error('Error saving item:', error);
            }
        }
    };

    const handleEditItem = (id) => {
        const itemToEdit = billItems.find(item => item._id === id);
        setItemData({ itemId: itemToEdit.itemId, quantity: itemToEdit.quantity });
        setEditItemId(id);
    };

    const handleDeleteItem = async (id) => {
        try {
            await deleteBillItemById(id);
            const updatedBillItems = billItems.filter(item => item._id !== id);
            setBillItems(updatedBillItems);
            calculateTotal(updatedBillItems);
        } catch (error) {
            console.error('Error deleting item:', error);
        }
    };

    const calculateTotal = (items) => {
        const total = items.reduce((sum, item) => sum + (item.total || 0), 0);
        setTotalAmount(total);
    };

    return (
        <Container>
            <h2 className="text-center mb-4">Bill</h2>
            {showSuccessAlert && (
                <Alert variant="success" onClose={() => setShowSuccessAlert(false)} dismissible>
                    Item {editItemId ? 'updated' : 'added'} successfully!
                </Alert>
            )}
            <Row className="mb-4">
                <Col xs={12} md={6}>
                    <Form.Group controlId="itemId">
                        <Form.Select name="itemId" value={itemData.itemId} onChange={handleChange} isInvalid={!!itemErrors.itemId}>
                            <option value="">Select Item</option>
                            {Array.isArray(items) && items.map(item => (
                                <option key={item._id} value={item._id}>
                                    {item.itemName} - ₹{item.itemPrice ? item.itemPrice.toFixed(2) : '0.00'}
                                </option>
                            ))}
                        </Form.Select>
                        <Form.Control.Feedback type="invalid">{itemErrors.itemId}</Form.Control.Feedback>
                    </Form.Group>
                </Col>
                <Col xs={12} md={3}>
                    <Form.Group controlId="quantity">
                        <Form.Control
                            type="number"
                            name="quantity"
                            value={itemData.quantity}
                            onChange={handleChange}
                            min="1"
                            isInvalid={!!itemErrors.quantity}
                        />
                        <Form.Control.Feedback type="invalid">{itemErrors.quantity}</Form.Control.Feedback>
                    </Form.Group>
                </Col>
                <Col xs={12} md={3}>
                    <Button variant="primary" onClick={handleAddOrEditItem}>
                        {editItemId ? 'Update Item' : 'Add Item'}
                    </Button>
                </Col>
            </Row>
            <Table striped bordered hover>
                <thead>
                    <tr>
                        <th>Item Name</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Total</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {billItems.map(item => (
                        <tr key={item._id}>
                            <td>{item.name}</td>
                            <td>₹{item.price ? item.price.toFixed(2) : '0.00'}</td>
                            <td>{item.quantity}</td>
                            <td>₹{item.total ? item.total.toFixed(2) : '0.00'}</td>
                            <td>
                                <Button variant="info" size="sm" onClick={() => handleEditItem(item._id)}>
                                    <MdEdit />
                                </Button>{' '}
                                <Button variant="danger" size="sm" onClick={() => handleDeleteItem(item._id)}>
                                    <MdDelete />
                                </Button>
                            </td>
                        </tr>
                    ))}
                </tbody>
                <tfoot>
                    <tr>
                        <td colSpan="3" className="text-right"><strong>Total:</strong></td>
                        <td>₹{totalAmount.toFixed(2)}</td>
                        <td></td>
                    </tr>
                </tfoot>
            </Table>
        </Container>
    );
};

export default Bill;
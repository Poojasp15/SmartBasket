import React, { useState, useEffect, useRef } from 'react';
import { Container, Row, Col } from 'react-bootstrap';
import ItemForm from './ItemForm';
import ItemList from './ItemList';
import { createItem, deleteItemById, getAllCategories, getAllItems, getAllSubcategoriesByCategoryId, updateItemById } from '../../utils/api';

const Items = () => {
    const [categories, setCategories] = useState([]);
    const [subcategories, setSubcategories] = useState([]);
    const [items, setItems] = useState([]);
    const [itemData, setItemData] = useState({
        category: '',
        subCategory: '',
        itemName: '',
        itemPrice: ''
    });
    const [itemErrors, setItemErrors] = useState({});
    const [showSuccessAlert, setShowSuccessAlert] = useState(false);
    const [showUpdateAlert, setShowUpdateAlert] = useState(false);
    const [showErrorAlert, setShowErrorAlert] = useState(false);
    const [isEditMode, setIsEditMode] = useState(false);
    const [editItemId, setEditItemId] = useState(null);
    const [searchQuery, setSearchQuery] = useState('');

    const formRef = useRef(null);

    useEffect(() => {
        fetchCategories();
        fetchItems();
    }, []);

    const fetchCategories = async () => {
        try {
            const response = await getAllCategories();
            if (response.ok) {
                const data = await response.json();
                setCategories(data);
            }
        } catch (error) {
            console.error('Error fetching categories:', error);
        }
    };

    const fetchSubcategories = async (categoryId) => {
        try {
            const response = await getAllSubcategoriesByCategoryId(categoryId);
            if (response.ok) {
                const data = await response.json();
                setSubcategories(data);
            }
        } catch (error) {
            console.error('Error fetching subcategories:', error);
        }
    };

    const fetchItems = async () => {
        try {
            const response = await getAllItems();
            if (response.ok) {
                const data = await response.json();
                setItems(data);
            }
        } catch (error) {
            console.error('Error fetching items:', error);
        }
    };

    const handleChange = (e) => {
        const { name, value } = e.target;
        if (name === 'category') {
            setItemData({ ...itemData, category: value, subCategory: '' });
            fetchSubcategories(value); // Fetch subcategories when a category is selected
        } else {
            setItemData({ ...itemData, [name]: value });
        }
    };

    const validateItem = () => {
        const errors = {};
        if (!itemData.category) errors.category = 'Category is required';
        if (!itemData.subCategory) errors.subCategory = 'Subcategory is required';
        if (!itemData.itemName) errors.itemName = 'Item name is required';
        if (!itemData.itemPrice) errors.itemPrice = 'Item price is required';
        return errors;
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        const errors = validateItem();

        if (Object.keys(errors).length > 0) {
            setItemErrors(errors);
            return;
        }

        setItemErrors({});
        try {
            let response;
            if (isEditMode) {
                response = await updateItemById(editItemId, itemData);
            } else {
                response = await createItem(itemData);
            }

            if (response.ok) {
                fetchItems();
                setItemData({
                    category: '',
                    subCategory: '',
                    itemName: '',
                    itemPrice: ''
                });
                setIsEditMode(false);
                setEditItemId(null);
                setShowSuccessAlert(!isEditMode);
                setShowUpdateAlert(isEditMode);
            } else {
                const responseData = await response.json();
                setShowErrorAlert(true);
                setItemErrors({ server: responseData.message });
            }
        } catch (err) {
            console.error('Error in try block:', err);
            setShowErrorAlert(true);
            setItemErrors({ server: `An error occurred. Please try again. ${err.message}` });
        }
    };

    const handleEdit = (item) => {
        setItemData({
            category: item.categoryId,
            subCategory: item.subCategoryId,
            itemName: item.itemName,
            itemPrice: item.itemPrice
        });
        setIsEditMode(true);
        setEditItemId(item._id);
        window.scrollTo({ top: 0, behavior: 'smooth' });
    };

    const handleDelete = async (item) => {
        if (window.confirm('Are you sure you want to delete this item?')) {
            try {
                const response = await deleteItemById(item._id);
                if (response.ok) {
                    alert("Item Deleted Successfully");
                    fetchItems();
                } else {
                    console.error('Failed to delete item');
                }
            } catch (error) {
                console.error('Error deleting item:', error);
            }
        }
    };

    return (
        <div>
            <Container className="container-1" ref={formRef}>
                <ItemForm
                    itemData={itemData}
                    itemErrors={itemErrors}
                    handleChange={handleChange}
                    handleSubmit={handleSubmit}
                    isEditMode={isEditMode}
                    showSuccessAlert={showSuccessAlert}
                    showUpdateAlert={showUpdateAlert}
                    showErrorAlert={showErrorAlert}
                    setShowSuccessAlert={setShowSuccessAlert}
                    setShowUpdateAlert={setShowUpdateAlert}
                    setShowErrorAlert={setShowErrorAlert}
                    categories={categories}
                    subcategories={subcategories}
                />
            </Container>

            <Container className="container-1">
                <Row>
                    <Col xs={12} sm={12}>
                        <ItemList
                            items={items}
                            handleEdit={handleEdit}
                            handleDelete={handleDelete}
                            searchQuery={searchQuery}
                            setSearchQuery={setSearchQuery}
                        />
                    </Col>
                </Row>
            </Container>
        </div>
    );
};

export default Items;
import React from 'react';
import { Button, Col, Form, Row, Alert } from 'react-bootstrap';

const ItemForm = ({
    itemData,
    itemErrors,
    handleChange,
    handleSubmit,
    isEditMode,
    showSuccessAlert,
    showUpdateAlert,
    showErrorAlert,
    setShowSuccessAlert,
    setShowUpdateAlert,
    setShowErrorAlert,
    categories,
    subcategories
}) => {
    return (
        <div className="form form-2">
            <h2 className="text-center mb-4">{isEditMode ? 'Edit Item' : 'Add Item'}</h2>
            {showSuccessAlert && (
                <Alert variant="success" onClose={() => setShowSuccessAlert(false)} dismissible>
                    Item added successfully!
                </Alert>
            )}
            {showUpdateAlert && (
                <Alert variant="success" onClose={() => setShowUpdateAlert(false)} dismissible>
                    Item updated successfully!
                </Alert>
            )}
            {showErrorAlert && (
                <Alert variant="danger" onClose={() => setShowErrorAlert(false)} dismissible>
                    Failed to {isEditMode ? 'update' : 'add'} item. {itemErrors.server}
                </Alert>
            )}

            <Form onSubmit={handleSubmit}>
                <Row>
                    <Col xs={12} sm={6}>
                        <Form.Group controlId="category" className="pb-4">
                            <Form.Select
                                name="category"
                                value={itemData.category}
                                onChange={handleChange}
                                isInvalid={!!itemErrors.category}
                            >
                                <option value="">Select Category</option>
                                {categories.map(category => (
                                    <option key={category._id} value={category._id}>
                                        {category.category}
                                    </option>
                                ))}
                            </Form.Select>
                            <Form.Control.Feedback type="invalid">
                                {itemErrors.category}
                            </Form.Control.Feedback>
                        </Form.Group>
                    </Col>
                    <Col xs={12} sm={6}>
                        <Form.Group controlId="subCategory" className="pb-4">
                            <Form.Select
                                name="subCategory"
                                value={itemData.subCategory}
                                onChange={handleChange}
                                isInvalid={!!itemErrors.subCategory}
                            >
                                <option value="">Select Subcategory</option>
                                {subcategories.map(subcategory => (
                                    <option key={subcategory._id} value={subcategory._id}>
                                        {subcategory.subCategory}
                                    </option>
                                ))}
                            </Form.Select>
                            <Form.Control.Feedback type="invalid">
                                {itemErrors.subCategory}
                            </Form.Control.Feedback>
                        </Form.Group>
                    </Col>
                </Row>
                <Row>
                    <Col xs={12} sm={6}>
                        <Form.Group controlId="itemName" className="pb-4">
                            <Form.Control
                                type="text"
                                name="itemName"
                                value={itemData.itemName}
                                onChange={handleChange}
                                isInvalid={!!itemErrors.itemName}
                                placeholder="Item Name"
                            />
                            <Form.Control.Feedback type="invalid">
                                {itemErrors.itemName}
                            </Form.Control.Feedback>
                        </Form.Group>
                    </Col>
                    <Col xs={12} sm={6}>
                        <Form.Group controlId="itemPrice" className="pb-4">
                            <Form.Control
                                type="number"
                                name="itemPrice"
                                value={itemData.itemPrice}
                                onChange={handleChange}
                                isInvalid={!!itemErrors.itemPrice}
                                placeholder="Item Price"
                            />
                            <Form.Control.Feedback type="invalid">
                                {itemErrors.itemPrice}
                            </Form.Control.Feedback>
                        </Form.Group>
                    </Col>
                </Row>
                <Button variant="primary" type="submit" className="mt-2 signup-button">
                    {isEditMode ? 'Update' : 'Add'}
                </Button>
            </Form>
        </div>
    );
};

export default ItemForm;
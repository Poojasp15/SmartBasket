// components/ItemList.js

import React, { useState } from 'react';
import { Button, Col, Form, Row } from 'react-bootstrap';
import { MdEdit, MdDelete } from 'react-icons/md';

const ItemList = ({ items, handleEdit, handleDelete }) => {
    const [searchQuery, setSearchQuery] = useState('');

    const filteredItems = items.filter(item =>
        item.itemName.toLowerCase().includes(searchQuery.toLowerCase())
    );

    const handleSearchChange = (e) => {
        setSearchQuery(e.target.value);
    };

    const handleSearchSubmit = (e) => {
        e.preventDefault(); // Prevent form submission if needed
        // Additional search logic can be implemented here if necessary
    };

    return (
        <div className="list-container scrollable-list">
            <Form onSubmit={handleSearchSubmit}>
                <Row>
                    <Col xs={12} sm={8}>
                        <h2 className="mb-4">List of Items</h2>
                    </Col>
                    <Col xs={12} sm={4} className="d-flex">
                        <Form.Group controlId="search" className="flex-grow-1">
                            <Form.Control
                                type="text"
                                placeholder="Search by Item Name"
                                value={searchQuery}
                                onChange={handleSearchChange}
                            />
                        </Form.Group>
                        <Button type="submit" variant="primary" className="ml-2">
                            Search
                        </Button>
                    </Col>
                </Row>
                <Row className="table-header pb-2 pt-2 GuestHeader">
                    <Col xs={1} className="text-center">Sl. No.</Col>
                    <Col xs={4} className="text-center">Item Name</Col>
                    <Col xs={4} className="text-center">Item Price</Col>
                    <Col xs={1} className="text-center">Edit</Col>
                    <Col xs={1} className="text-center">Delete</Col>
                </Row>

                {filteredItems.map((item, index) => (
                    <Row key={item._id} className="table-row">
                        <Col xs={1} className="text-center">{index + 1}</Col>
                        <Col xs={4} className="text-center">{item.itemName}</Col>
                        <Col xs={4} className="text-center">{item.itemPrice}</Col>
                        <Col xs={1} className="text-center">
                            <Button variant="primary" onClick={() => handleEdit(item)}>
                                <MdEdit />
                            </Button>
                        </Col>
                        <Col xs={1} className="text-center">
                            <Button variant="danger" onClick={() => handleDelete(item)}>
                                <MdDelete />
                            </Button>
                        </Col>
                    </Row>
                ))}
            </Form>
        </div>
    );
};

export default ItemList;
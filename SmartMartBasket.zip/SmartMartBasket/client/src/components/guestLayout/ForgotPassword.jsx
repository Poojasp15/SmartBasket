import React from 'react'

const ForgotPassword = () => {
  return (
    <div>
      
    </div>
  )
}

export default ForgotPassword

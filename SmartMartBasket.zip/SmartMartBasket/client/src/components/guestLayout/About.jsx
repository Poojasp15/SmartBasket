import React from 'react';

// Inline styles for basic styling
const styles = {
  container: {
    padding: '20px',
    maxWidth: '800px',
    margin: '0 auto',
    textAlign: 'center',
  },
  header: {
    fontSize: '2rem',
    marginBottom: '20px',
    color: '#2c3e50',
  },
  section: {
    marginBottom: '20px',
    textAlign: 'left',
  },
  sectionTitle: {
    fontSize: '1.5rem',
    marginBottom: '10px',
    color: '#2980b9',
  },
  paragraph: {
    lineHeight: '1.6',
    color: '#34495e',
  },
  list: {
    listStyleType: 'disc',
    marginLeft: '20px',
  },
};

const About = () => {
    return (
      <div style={styles.container}>
        <h1 style={styles.header}>About AI Driven Virtual Shopping Assistant</h1>
        <div style={styles.section}>
          <h2 style={styles.sectionTitle}>What is an AI Driven Virtual Shopping Assistant?</h2>
          <p style={styles.paragraph}>
            An AI Driven Virtual Shopping Assistant is an innovative solution that leverages artificial intelligence 
            to enhance the online shopping experience. It assists customers in finding products, comparing prices, 
            and making informed purchasing decisions through interactive conversations.
          </p>
        </div>
        <div style={styles.section}>
          <h2 style={styles.sectionTitle}>Key Features</h2>
          <ul style={styles.list}>
            <li style={styles.paragraph}>Personalized product recommendations based on user preferences.</li>
            <li style={styles.paragraph}>Real-time assistance and answers to product-related queries.</li>
            <li style={styles.paragraph}>Price comparison across different online retailers.</li>
            <li style={styles.paragraph}>Seamless integration with e-commerce platforms.</li>
          </ul>
        </div>
        <div style={styles.section}>
          <h2 style={styles.sectionTitle}>Benefits of the AI Driven Virtual Shopping Assistant</h2>
          <p style={styles.paragraph}>
            The AI Driven Virtual Shopping Assistant offers several benefits including:
          </p>
          <ul style={styles.list}>
            <li style={styles.paragraph}>Enhanced shopping experience through personalized interactions.</li>
            <li style={styles.paragraph}>Increased efficiency in finding and purchasing products.</li>
            <li style={styles.paragraph}>Reduction in the time spent searching for the best deals.</li>
            <li style={styles.paragraph}>24/7 availability for customer assistance.</li>
          </ul>
        </div>
      </div>
    );
};

export default About;
import React from 'react'
import NavBar from './NavBar'

const GuestHeader = () => {
    return (
        <div>
            <NavBar />
        </div>
    )
}

export default GuestHeader

import React from 'react'

const GuestFooter = () => {
  return (
    <div>
      <h1>Designed By BE Students</h1>
    </div>
  )
}

export default GuestFooter
import React from 'react';

const Contact = () => {
    const styles = {
        container: {
            padding: '20px',
            maxWidth: '800px',
            margin: '0 auto',
            textAlign: 'center',
        },
        header: {
            fontSize: '2rem',
            marginBottom: '20px',
            color: '#2c3e50',
        },
        section: {
            marginBottom: '20px',
            textAlign: 'left',
        },
        sectionTitle: {
            fontSize: '1.5rem',
            marginBottom: '10px',
            color: '#2980b9',
        },
        paragraph: {
            lineHeight: '1.6',
            color: '#34495e',
        },
        list: {
            listStyleType: 'disc',
            marginLeft: '20px',
        },
        contactList: {
            listStyleType: 'none',
            padding: 0,
        },
        contactItem: {
            marginBottom: '10px',
            color: '#34495e',
        },
    };

    return (
        <div style={styles.container}>
            <h1 style={styles.header}>Contact Details</h1>
            
            {/* Section for Contact Information */}
            <div style={styles.section}>
                <h2 style={styles.sectionTitle}>Contact Information</h2>
                <p style={styles.paragraph}>
                    Below are some dummy contact details that may be useful for various inquiries:
                </p>
                <ul style={styles.contactList}>
                    <li style={styles.contactItem}>
                        <strong>John Doe</strong><br />
                        Email: johndoe@example.com<br />
                        Phone: +1 (555) 111-2222<br />
                        Address: 101 Example Street, Anytown, USA
                    </li>
                    <li style={styles.contactItem}>
                        <strong>Jane Smith</strong><br />
                        Email: janesmith@example.com<br />
                        Phone: +1 (555) 222-3333<br />
                        Address: 202 Sample Avenue, Sample City, USA
                    </li>
                    <li style={styles.contactItem}>
                        <strong>Mike Johnson</strong><br />
                        Email: mikejohnson@example.com<br />
                        Phone: +1 (555) 333-4444<br />
                        Address: 303 Test Road, Testing Town, USA
                    </li>
                    <li style={styles.contactItem}>
                        <strong>Emily Davis</strong><br />
                        Email: emilydavis@example.com<br />
                        Phone: +1 (555) 444-5555<br />
                        Address: 404 Demo Blvd, Demo City, USA
                    </li>
                </ul>
            </div>
        </div>
    );
};

export default Contact;
import React from 'react'
import { NavLink, useNavigate } from 'react-router-dom'
import { Navbar, Container, Nav, NavDropdown, Dropdown } from 'react-bootstrap'
import { useUserData } from '../../utils/Cookies';
import Cookies from 'js-cookie';
import { CgProfile } from 'react-icons/cg';
import { FaUserEdit } from 'react-icons/fa';
import { PiPasswordLight } from 'react-icons/pi';
import { MdLogout } from 'react-icons/md';

const NavBar = () => {

    const { user: userData } = useUserData();
    const history = useNavigate();

    const navigate = useNavigate();

    const handleSelect = (eventKey) => {
        switch (eventKey) {
            case 'edit-profile':
                navigate('/edit-profile');
                break;
            case 'change-password':
                navigate('/changePassword');
                break;
            case 'logout':
                // Clear cookies
                Cookies.remove('userData');
                // Clear session storage
                sessionStorage.clear();
                // Clear local storage if needed
                localStorage.clear();
                // Navigate to login and replace history
                navigate('/', { replace: true });
                // Use window.location.replace to ensure no back navigation
                window.location.replace('/');
                break;
            default:
                break;
        }
    };

    return (
        <div>
            <Navbar collapseOnSelect expand="lg" variant="light">
                <Container>
                    <Navbar.Brand href="/home">Virtual Shopping Assistant   </Navbar.Brand>
                    <Navbar.Toggle aria-controls="responsive-navbar-nav" />
                    <Navbar.Collapse id="responsive-navbar-nav">
                        <Nav className="me-auto">
                            <Nav.Link as={NavLink} to="/home">Home</Nav.Link>
                            <Nav.Link as={NavLink} to="/about">About</Nav.Link>
                            <Nav.Link as={NavLink} to="/contact">Contact</Nav.Link>
                            <Nav.Link as={NavLink} to="/register">Register</Nav.Link>
                            <Nav.Link as={NavLink} to="/login">Login</Nav.Link>
                        </Nav>
                    </Navbar.Collapse>

                    {userData._id &&
                        <Dropdown onSelect={handleSelect}>
                            <Dropdown.Toggle variant=''>
                                {userData.firstName} {userData.lastName} <CgProfile />
                            </Dropdown.Toggle>

                            <Dropdown.Menu variant=''>
                                <Dropdown.Item eventKey="edit-profile">
                                    Edit Profile <FaUserEdit />
                                </Dropdown.Item>
                                <Dropdown.Item eventKey="change-password">
                                    Change Password <PiPasswordLight />
                                </Dropdown.Item>
                                <Dropdown.Item eventKey="logout">
                                    Logout <MdLogout />
                                </Dropdown.Item>
                            </Dropdown.Menu>
                        </Dropdown>
                    }

                </Container>
            </Navbar>

        </div>
    )
}

export default NavBar
